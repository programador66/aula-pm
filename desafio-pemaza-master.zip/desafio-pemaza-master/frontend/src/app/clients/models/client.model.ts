export class Client {
  public id?: number;
  public code: string;
  public name: string;
  public register: boolean | string;
}
